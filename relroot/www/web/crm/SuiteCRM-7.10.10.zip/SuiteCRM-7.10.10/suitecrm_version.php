<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.10.10';
$suitecrm_timestamp    = '2018-10-24 17:00';
